﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyAppCRUD.Repository;

namespace MyAppCRUD.Controllers
{
    public class BaseController : Controller
    {
        public dbsys32Entities1 _db;
        public BaseRepository<user> _userRepo;

        public BaseController()
        {
            _db = new dbsys32Entities1();
            _userRepo = new BaseRepository<user>();

        }
    }
}